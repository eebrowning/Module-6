# INHERITANCE
#
# Define two classes in this file.
#
# The "Light" class must have no constructor. It can be an empty class.
#
# The "LED" class should inherit from the "Light" class. It should have
# an empty constructor. It can be an empty class.
class Light:
    pass


class LED(Light):
    pass


# WRITE YOUR CODE HERE
# Your code here
