You only need to use the files in this folder if you are using _Blueprints_.
